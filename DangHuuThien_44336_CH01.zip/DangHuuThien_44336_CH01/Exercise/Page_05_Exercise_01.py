"""
Author: Dang Huu Thien
Date: 28/08/2021
Problem:List three common types of computing agents.
Solution:
   Thiết bị CPU, bộ nhớ, đầu vào và đầu ra
          ....
"""
