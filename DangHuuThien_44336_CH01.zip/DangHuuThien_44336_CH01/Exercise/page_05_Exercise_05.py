"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:In what sense is a laptop computer a general-purpose problem-solving machine?
Solution:
 Nó tự động hóa các nhiệm vụ giải quyết các vấn đề được giải quyết bằng các thuật toán.
    ....