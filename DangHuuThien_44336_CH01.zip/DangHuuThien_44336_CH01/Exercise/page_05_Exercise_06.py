"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:List four devices that use computers and describe the information that they process.
Solution:
  Hai thiết bị đầu ra là màn hình và loa chuyển đổi kết quả xử lý tính toán trở lại dạng có thể sử dụng của con người
  Hai thiết bị đầu vào là bàn phím và micrô, chúng chuyển đổi thông tin như văn bản, âm thanh thành thông tin để xử lý tính toán.
    ....