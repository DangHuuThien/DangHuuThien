"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:List two examples of input devices and two examples of output devices
Solution:
  Hai thiết bị đầu ra là màn hình và loa,Hai thiết bị đầu vào là bàn phím và micrô
    ....