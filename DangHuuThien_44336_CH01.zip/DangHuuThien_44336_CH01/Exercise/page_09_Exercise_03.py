"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem: How is information represented in hardware memory?
Solution:
  Nó được lưu trữ dưới dạng chữ số nhị phân.Ví dụ các loại dữ liệu như số, văn bản, hình ảnh, âm thanh hoặc hướng dẫn của chương trình
    ....