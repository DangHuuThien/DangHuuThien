"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:What is the difference between a terminal-based interface and a graphical user interface?
Solution:
 Giao diện dựa trên thiết bị đầu cuối chấp nhận đầu vào từ bàn phím.
 Giao diện người dùng đồ họa cho phép người dùng thao tác hình ảnh bằng các thiết bị trỏ như chuột.
    ....