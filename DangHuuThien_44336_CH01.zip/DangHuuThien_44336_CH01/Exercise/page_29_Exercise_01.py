"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:  Describe what happens when the programmer enters the string "Greetings!" in
the Python shell.
Solution:
  Nó sẽ in chuỗi 'Lời chào'
    ....