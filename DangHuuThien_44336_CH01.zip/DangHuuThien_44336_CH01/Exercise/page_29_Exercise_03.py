"""
Author: Dang Huu Thien
Date: 25/08/2021
Problem:  Answer the question, What is a Python script?
Solution:
  A program that that is saved in files and ran from a terminal command prompt.
    ....