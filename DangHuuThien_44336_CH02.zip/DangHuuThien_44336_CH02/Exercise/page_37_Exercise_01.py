
"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:List four phases of the software development process, and explain what they
accomplish.
Solution:
  1.Integration
  2.Design
  3.Implementation
  4.Analysis
   ....
"""