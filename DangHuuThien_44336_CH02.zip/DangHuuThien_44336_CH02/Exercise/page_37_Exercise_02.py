"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Jack says that he will not bother with analysis and design but proceed directly to
coding his programs. Why is that not a good idea
Solution:
   If Jack would not bother with design and analysis process,then he would not be able to understand the basis functionality flown of the problem. Understanding of problem is required before the actual implementation to create a prototype of the program,otherwise the programmer can lose track.

   ....
"""