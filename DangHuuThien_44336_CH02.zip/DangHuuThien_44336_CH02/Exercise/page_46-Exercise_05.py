"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem: Which of the following are valid variable names?
a. length
b. _width
c. firstBase
d. 2MoreToGo
e. halt!
Solution:
   a.Đúng
   b.Đúng
   c.Đúng
   d.sai
   e.Sai
   ....
"""