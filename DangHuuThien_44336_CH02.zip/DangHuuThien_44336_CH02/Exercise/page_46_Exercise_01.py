"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Let the variable x be "dog" and the variable y be "cat". Write the values returned
by the following operations:
a. x + y
b. "the " + x + " chases the " + y
c. x * 4
Solution:
   >>> x = "dog"
>>> y = "cat"
>>> x+y
'dogcat'
>>> "
  File "<stdin>", line 1
    "
    ^
SyntaxError: EOL while scanning string literal
>>>
>>>

(base) H:\Code python>python
Python 3.8.8 (default, Apr 13 2021, 15:08:03) [MSC v.1916 64 bit (AMD64)] :: Anaconda, Inc. on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> x = "dog"
>>> y = "cat"
>>> x+y
'dogcat'
>>> "The" + x + "chases the" + y
'Thedogchases thecat'
>>> x*4
'dogdogdogdog'
   ....
"""