"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Write a string that contains your name and address on separate lines using embedded newline characters. Then write the same string literal without the newline
characters.
Solution:

   ....
"""
print ("dang huu thien")
print("quang ngai")