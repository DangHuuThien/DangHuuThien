"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem: How does one include an apostrophe as a character within a string literal?
Solution:
  The string value should be enclosed within double quotes to include apostrophe as a character in any string literal
   Three consecutive quotation marrks can also be used for this purpose
   ....
"""