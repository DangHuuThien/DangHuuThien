"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:List two of the purposes of program documentation.
Solution:
  Program documentation is used to define the startege used by the module or code.
  Documentation written in the program helps other programmer who have not written the code, to understand
  the functionality and the usage of variables and functions.
   ....
"""