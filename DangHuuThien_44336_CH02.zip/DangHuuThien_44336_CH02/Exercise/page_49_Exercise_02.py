"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Explain the differences between the data types int and float
Solution:
   Int: kiểu dữ liệu số nguyên.
   Float: kiểu dữ liệy số thực.
   ....
"""