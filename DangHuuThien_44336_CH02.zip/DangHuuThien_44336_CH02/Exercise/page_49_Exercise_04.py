"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Consult Table 2-5 to write the ASCII values of the characters '$' and '&'
Solution:
   >>> ord('$')
   36
   >>> ord('&')
   38
   ....
"""