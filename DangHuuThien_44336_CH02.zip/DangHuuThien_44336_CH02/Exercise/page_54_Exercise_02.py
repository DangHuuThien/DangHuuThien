"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem: Let x 5 4.66 Write the values of the following expressions:
a. round(x)
b. int(x)
Solution:
   >>> x=4.66
   >>> round(x)
   5
   >>> int(x)
   4
   ....
"""
