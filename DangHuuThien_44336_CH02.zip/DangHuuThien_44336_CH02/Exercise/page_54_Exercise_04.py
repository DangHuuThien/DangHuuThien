"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:How does a Python programmer concatenate a numeric value to a string value?
Solution:
  To concatenate a numeric value to a string,the numeric value ís converted to string value using method
  Then using + operator two strings are concatenated.
   ....
"""