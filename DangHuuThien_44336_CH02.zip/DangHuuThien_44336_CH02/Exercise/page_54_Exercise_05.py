"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:ssume that the variable x has the value 55
        Use an assignment statement to increment the value of x by 1.
Solution:
   >>> x=55
   >>> x+1
   56
   ....
"""