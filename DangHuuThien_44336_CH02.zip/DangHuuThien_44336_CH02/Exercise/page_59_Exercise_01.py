"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Explain the relationship between a function and its arguments.
Solution:
   Arguments may or may not be used in the function.
   Arguments can be required as well as it can be optional.
   ....
"""