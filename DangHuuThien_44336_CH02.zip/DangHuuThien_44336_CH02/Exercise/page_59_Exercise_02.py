"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:The math module includes a pow function that raises a number to a given power.
The first argument is the number, and the second argument is the exponent. Write
a code segment that imports this function and calls it to print the values 82
 and 54
Solution:
   >>> pow(8,2)
   64
   >>> pow(5,4)
   625
   ....
"""