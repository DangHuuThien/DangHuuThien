"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Explain how to display a directory of all of the functions in a given module
Solution:
   Using dir method, the directory of all the functions in a module can be displayed.
   To pass module name into dir function, import the module and the pass it as argument in dir function.
   ....
"""