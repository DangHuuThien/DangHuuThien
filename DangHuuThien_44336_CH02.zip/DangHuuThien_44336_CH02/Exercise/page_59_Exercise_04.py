"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Explain how to display help information on a particular function in a given module.
Solution:
   Using the help method, the information about a particular function in a module can be displayed.
   To pass a function name into the help function, import the function from the module and then pass it as an
   argument in the help function.
   ....
"""