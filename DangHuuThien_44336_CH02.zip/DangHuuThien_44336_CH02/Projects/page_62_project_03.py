"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Five Star Retro Video rents VHS tapes and DVDs to the same connoisseurs who
like to buy LP record albums. The store rents new videos for $3.00 a night, and
oldies for $2.00 a night. Write a program that the clerks at Five Star Retro Video
can use to calculate the total charge for a customer’s video rentals. The program
should prompt the user for the number of each type of video and output the total
cost
Solution:
   Gắn số tiền new video và oldies
   Sô lượng và thơi gian thuê video
   Tính toán
   ....
"""
moi = 4.00
cu = 2.00
soluong_moi =int(input("soluong_moi:"))
soluong_cu =int(input("soluong_cu:"))
songay = int(input("songay:"))
tong_moi=moi*soluong_cu
tong_cu=cu*soluong_cu
thanhtoan=(tong_moi+tong_cu)*songay
print("moi", soluong_moi,tong_moi)
print("cu",soluong_cu,tong_cu)
print("thanhtoan:",thanhtoan)