"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:Write a program that takes the radius of a sphere (a floating-point number) as
input and then outputs the sphere’s diameter, circumference, surface area, and
volume.
Solution:
   ....
"""
ban_kinh=int(input("duong_kinh"))
duong_kinh=2* ban_kinh
duong_tron=duong_kinh*3.14
dientichbemat=4*3.14*ban_kinh*ban_kinh
khoi_luong=(4/3)*3.14*ban_kinh*ban_kinh*ban_kinh
print("duong_kinh",duong_kinh)
print("duong_tron",duong_tron)
print("dientienbemat",dientichbemat)
print("khoi_luong",khoi_luong)

