"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:An object’s momentum is its mass multiplied by its velocity. Write a program
that accepts an object’s mass (in kilograms) and velocity (in meters per second) as
inputs and then outputs its momentum.
Solution:
   ....
"""
khoiluong= float(input("khoiluong: "))
vantoc= float(input("vantoc: "))
quantinh= khoiluong * vantoc
print("dong luong cua vat la",quantinh)


