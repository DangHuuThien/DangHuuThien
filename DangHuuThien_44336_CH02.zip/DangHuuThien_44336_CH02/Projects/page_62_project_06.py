"""
Author: Dang Huu Thien
Date: 01/09/2021
Problem:The kinetic energy of a moving object is given by the formula KE 1 2/ mv 5 2 ( )
where m is the object’s mass and v is its velocity. Modify the program you created
in Project 5 so that it prints the object’s kinetic energy as well as its momentum
Solution:

   ....
"""
khoi_luong=float(input("khoi_luong:"))
van_toc=float(input("van_toc:"))
KE = 0.5*khoi_luong*van_toc**2
quan_tinh=khoi_luong*van_toc
print("dong luong cua vat la:"+str(quan_tinh))
print("dong nang cua vat la:"+str(KE))