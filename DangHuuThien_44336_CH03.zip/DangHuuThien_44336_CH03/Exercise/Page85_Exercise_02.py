"""
Author: Dang Huu Thien
Date: 19/09/2021
Problem:
   Assume that x refers to a number. Write a code segment that prints the number’s
absolute value without using Python’s abs function.
Solution:
 x=int(input("Enter x:"))
 if x < 0:
 x = –x
 print("x: ",x)
    ....
"""