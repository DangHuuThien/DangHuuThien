"""
Author: Dang Huu Thien
Date: 19/09/2021
Problem:
    Explain the role of the variable in the header of a for loop.
Solution:
 for loop header:
 for value in range(num)
    ....
"""