"""
Author: Dang Huu Thien
Date: 19/09/2021
Problem:Write a code segment that displays the values of the integers x, y, and z on a single
line, such that each value is right-justified with a field width of 6.
Solution:
x = 26
y = 30
z = 15
print("%6d" % x)
print("%6d" % y)
print("%6d" % z)
   ....
"""
