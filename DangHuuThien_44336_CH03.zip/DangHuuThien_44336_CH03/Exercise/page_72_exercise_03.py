"""
Author: Dang Huu Thien
Date: 19/09/2021
Problem:Write a format operation that builds a string for the float variable amount that has
exactly two digits of precision and a field width of zero.
Solution:
x = 123
y = 26
print("%0.2f" % x)
print("%0.2f" % y)
   ....
"""
