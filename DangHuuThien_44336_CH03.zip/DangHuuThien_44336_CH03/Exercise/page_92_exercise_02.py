"""
Author: Dang Huu Thien
Date: 19/09/2021
Problem:The factorial of an integer N is the product of the integers between 1 and N, inclu-sive.
Write a while loop that computes the factorial of a given integer N
Solution:
theSum = 0.0
while True:
    data = input("Enter a number or just enter to quit: ")
    if data == "":
        break
    number = float(data)
    theSum *= number
print("The sum is", theSum)
   ....
"""