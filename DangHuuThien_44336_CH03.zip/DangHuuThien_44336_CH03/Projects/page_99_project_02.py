"""
Author: Dang Huu Thien
Date: 09/09/2021
Problem:Write a program that accepts the lengths of three sides of a triangle as inputs.
The program output should indicate whether or not the triangle is a right triangle. Recall from the Pythagorean theorem that in a right triangle, the square of
one side equals the sum of the squares of the other two sides.
Solution:
   ....
"""
a = int(input("nhập độ dài cạnh a: "))
b = int(input("nhập độ dài cạnh b: "))
c = int(input("nhập độ dài cạnh c: "))
if a**2 == b**2 + c**2:
    print("tam giác abc là tam giác vuông")
elif b**2 == c**2 + a**2:
    print("tam giác abc là tam giác vuông")
elif c**2 == b**2 + a**2:
    print("tam giác abc là tam giác vuông")
else:
    print("tam giác abc không phải là tam giác vuông")