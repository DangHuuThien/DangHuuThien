"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:
Assume that the variable myString refers to a string. Write a code segment that
uses a loop to print the characters of the string in reverse order.
Solution:
    ....
"""
a = "myString"
for b in range(len(a)):
    print(b, a[b])
