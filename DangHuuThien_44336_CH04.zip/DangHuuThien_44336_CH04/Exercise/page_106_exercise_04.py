"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:
Assume that the variable myString refers to a string, and the variable
reversedString refers to an empty string. Write a loop that adds the characters
from myString to reversedString in reverse order.
Solution:
    ....
"""
X = "helloWord"
Y = ""
for a in range (len(X)):
    Y = X
    print(a, Y[a])