"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:
Consult the Table of ASCII values in Chapter 2 and suggest how you would modify
the encryption and decryption scripts in this section to work with strings containing all of the printable characters.
Solution:
- ASCII stands for American Standard code for in fomation interchange
    - This is a character coding standard that represents both printable and non - printable characters
    - ASCII can represent a total of 128 characters out of which 95 are printable and the remaining 33
      charaters are non - printable charaters
    - printable characters include digits from 0 to 9, upper case letters A to Z, lower case letters a to Z
      and punctuation symbol
    ....
"""