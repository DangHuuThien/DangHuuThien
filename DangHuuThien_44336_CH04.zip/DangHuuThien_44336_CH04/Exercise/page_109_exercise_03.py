"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:
You are given a string that was encoded by a Caesar cipher with an unknown distance value. The text can contain any of the printable ASCII characters. Suggest an
algorithm for cracking this code
Solution:
    ....
"""
plainText = "DangHuuThien"
for ch in plainText:
    ordvalue = ord(ch)
    print(ordvalue)