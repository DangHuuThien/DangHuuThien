"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:Translate each of the following numbers to binary numbers:
a. 478
b. 1278
c. 648
Solution:
    a. 47  >>> 100111
    b. 127 >>> 001010111
    c. 64  >>> 110100
    ....
"""