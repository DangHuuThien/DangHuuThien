"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:4. Translate each of the following numbers to decimal numbers:
a. 478
b. 1278
c. 648
Solution:
    a. 47  >>>   39
    b. 127 >>>   87
    c. 64  >>>   52
    ....
"""