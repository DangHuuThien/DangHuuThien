"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:Translate each of the following numbers to decimal numbers:
a. 4716
b. 12716
c. AA16
Solution:
    a.   47    >>>   71
    b.   127   >>>   295
    c.   AA    >>>   170
    ....
"""