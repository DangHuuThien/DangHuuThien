"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:Octal numbers have a base of eight and the digits 0–7. Write the scripts octalToDecimal.py and decimalToOctal.py, which convert numbers between the octal
and decimal representations of integers. These scripts use algorithms that are
similar to those of the binaryToDecimal and decimalToBinary scripts developed in Section 4-3.
Solution:
    ....
"""
#decimalToOctal
def decToOct(dec):
    return oct(dec)
print(decToOct(42))
#OctToDec
def octToDec(oct):
    return int(oct, 8)
print(octToDec('0o52'))
