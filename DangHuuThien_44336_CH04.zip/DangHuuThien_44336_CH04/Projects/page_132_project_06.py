"""
Author: Dang Huu Thien
Date: 23/09/2021
Problem:
Solution:
    ....
"""