"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
Write a loop that accumulates the sum of the numbers in a list named data.
Solution:

"""
total = 0
for num in data:
 total += num
print(total)

