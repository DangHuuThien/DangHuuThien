"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
 Write a loop that replaces each number in a list named data with its absolute value.
Solution:
"""
int_num = -25

float_num = -10.50

print("The absolute value of an integer number is:", abs(int_num))
print("The absolute value of a float number is:", abs(float_num))