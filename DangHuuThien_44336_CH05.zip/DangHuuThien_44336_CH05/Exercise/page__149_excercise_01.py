"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
What roles do the parameters and the return statement play in a function definition?
Solution:
Functions are code snippets which has its own header and body.
 Large program can be broken in to small pieces. It facilitates easy debugging and a good management of...


"""