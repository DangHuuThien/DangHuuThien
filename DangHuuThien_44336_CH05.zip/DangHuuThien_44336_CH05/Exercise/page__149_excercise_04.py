"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
Define a function named summation. This function expects two numbers, named
low and high, as arguments. The function computes and returns the sum of the
numbers between low and high, inclusive.
Solution:

"""