"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
What is the purpose of a main function?
Solution:
n C, program execution starts from the main() function. Every C program must contain a main() function.
 The main function may contain any number of statements.
hese statements are executed sequentially in the order which they are written.

The main function can in-turn call other functions. When main calls a function, it passes the execution
control to that function. The function returns control to main when a return statement is executed or when
 end of function is reached.
"""