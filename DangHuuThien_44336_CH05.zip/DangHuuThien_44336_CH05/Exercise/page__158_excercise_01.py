"""
Author: Đặng Hữu Thiện
Date: 9/10/2021
Problem:
Give three examples of real-world objects that behave like a dictionary.
Solution:
1.an object and its shadow are similar since the shapes are exactly the same .it only the size that varies
2.an anlarged retains  the shapes of the original picture. it only the size that varies
3.all ball are similar because they all have the same shapes.only the size may vary
"""