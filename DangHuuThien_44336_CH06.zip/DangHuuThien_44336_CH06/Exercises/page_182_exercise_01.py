"""
Author: Dang Huu Thien
Date: 22/10/2021
Problem:
    In what way is a recursive design different from top-down design?
Solution:
    In what way is a recursive design different from top-down design? Recursive
    functions are a type of functions in which the same function it called itself
    in the body of the function. A recursion should have a base case and an iteration case.
    The base case is the termination point at which the program should halt.

    ....
"""