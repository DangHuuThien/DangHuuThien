"""
Author: Dang Huu Thien
Date: 22/10/2021
Problem:
    The factorial of a positive integer n, fact(n), is defined recursively as follows:
    fact( ) n 1 5 , when n 1 5
     fact( ) n n 5 2 * fact n( ) 1 , otherwise
    Define a recursive function fact that returns the factorial of a given positive
    integer
Solution:
    int main()
{
    int n = 6, i;
    int fact = 1;
    for(i=1;i<=n;i++)
      _________;
    printf("%d",fact);
    return 0;
}
    ....
"""