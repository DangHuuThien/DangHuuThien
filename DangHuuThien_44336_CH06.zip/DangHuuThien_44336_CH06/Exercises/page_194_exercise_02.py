"""
Author: Dang Huu Thien
Date: 22/10/2021
Problem:

Solution:

    ....
"""