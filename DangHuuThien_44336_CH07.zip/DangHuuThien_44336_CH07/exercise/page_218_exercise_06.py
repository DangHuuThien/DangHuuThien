"""
Author: Dang Huu Thien
Date: 15/10/2021

Problem: The Turtle class includes a method named circle. Import the Turtle class, run help(Turtle.circle),
and study the documentation. Then use this method to draw a filled circle and a half moon.
Solution:


"""